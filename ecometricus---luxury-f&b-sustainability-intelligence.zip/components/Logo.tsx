
import React from 'react';

const Logo: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const dims = size === 'sm' ? 'w-8 h-8' : size === 'md' ? 'w-10 h-10' : 'w-16 h-16';
  return (
    <div className={`${dims} relative flex items-center justify-center`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
            <defs>
                <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style={{ stopColor: '#C8A413', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#8E730D', stopOpacity: 1 }} />
                </linearGradient>
                <linearGradient id="greenGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style={{ stopColor: '#77B139', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#152E2A', stopOpacity: 1 }} />
                </linearGradient>
            </defs>
            {/* Outer Circle Ring */}
            <path 
                d="M 50,5 A 45,45 0 1,1 50,95 A 45,45 0 1,1 50,5" 
                fill="none" 
                stroke="url(#goldGradient)" 
                strokeWidth="8" 
                strokeDasharray="200 80"
            />
            {/* Inner Leaves */}
            <path 
                d="M 50,70 Q 50,40 30,30 Q 45,35 50,60" 
                fill="url(#greenGradient)"
            />
             <path 
                d="M 50,70 Q 50,40 70,30 Q 55,35 50,60" 
                fill="url(#greenGradient)"
            />
            <path 
                d="M 50,70 L 50,35 Q 40,20 50,15 Q 60,20 50,35" 
                fill="url(#greenGradient)"
            />
            <rect x="48" y="70" width="4" height="15" fill="#C8A413" />
        </svg>
    </div>
  );
};

export default Logo;
